document.addEventListener('DOMContentLoaded', () => {
   displayGreeting(); 

    const editBtn = document.getElementById('editButton');
    const saveBtn = document.getElementById('saveButton');
    const cancelBtn = document.getElementById('cancelButton');
    
    if (editBtn) {
        editBtn.addEventListener('click', enableProfileEdit);
    }
    if (saveBtn) {
        saveBtn.addEventListener('click', updateProfile);
    }
    if (cancelBtn) {
        cancelBtn.addEventListener('click', disableProfileEdit);
    }

    const calculateButton = document.getElementById("calculateButton");
    if (calculateButton) {
        calculateButton.addEventListener('click', calculateCredits);
    }
    
    const contactForm = document.getElementById("contactForm");
    if (contactForm) {
        
        contactForm.addEventListener('submit', validateContactForm);
    }
});


function displayGreeting() {
    const greetingElement = document.getElementById("greeting");
    if (!greetingElement) return; 

    const hour = new Date().getHours();
    let greeting = "";

    if (hour >= 5 && hour < 12) {
        greeting = "GOOD MORNING!";
    } else if (hour >= 12 && hour < 17) {
        greeting = "GOOD AFTERNOON!";
    } else {
        greeting = "GOOD EVENING!";
    }

    greetingElement.innerText = greeting;
}

function disableProfileEdit() {
    const displaySection = document.getElementById('profileDetailsDisplay');
    const editSection = document.getElementById('editSection');
    const editButton = document.getElementById('editButton');

    if (!displaySection || !editSection || !editButton) return;
    
    editSection.style.display = 'none';
    displaySection.style.display = 'block';
    editButton.style.display = 'block';
}

function enableProfileEdit() {
    const displaySection = document.getElementById('profileDetailsDisplay');
    const editSection = document.getElementById('editSection');
    const editButton = document.getElementById('editButton');
    
    if (!displaySection || !editSection || !editButton) return; 

    displaySection.style.display = 'none';
    editButton.style.display = 'none';
    editSection.style.display = 'block';

    document.getElementById('editName').value = document.getElementById('nameValue').textContent;
    document.getElementById('editReg').value = document.getElementById('regnoValue').textContent;
    document.getElementById('editProgram').value = document.getElementById('programValue').textContent;
    document.getElementById('editEmail').value = document.getElementById('emailValue').textContent;
}

function updateProfile() {
    const newName = document.getElementById('editName').value;
    const newReg = document.getElementById('editReg').value;
    const newProgram = document.getElementById('editProgram').value;
    const newEmail = document.getElementById('editEmail').value;

    document.getElementById('nameValue').textContent = newName;
    document.getElementById('regnoValue').textContent = newReg;
    document.getElementById('programValue').textContent = newProgram;
    document.getElementById('emailValue').textContent = newEmail;

    const header = document.getElementById('programNameHeader');
    if (header) {
        header.textContent = `Academic Profile (${newProgram.split('/')[0].trim()})`;
    }
    
    disableProfileEdit();
    alert('Profile details updated successfully!');
}


function calculateCredits() {
    let credits = document.querySelectorAll(".credit");
    let total = 0;

    credits.forEach(c => {
        const creditValue = parseFloat(c.textContent.trim());
        if (!isNaN(creditValue)) {
            total += creditValue;
        }
    });

    const totalCreditsElement = document.getElementById("totalCredits");
    if (totalCreditsElement) {
        totalCreditsElement.innerText = `Total Credits: ${total.toFixed(1)}`;
    }
}

function validateContactForm(event) {
    event.preventDefault(); 

    const name = document.getElementById("contactName").value.trim();
    const email = document.getElementById("contactEmail").value.trim();
    const message = document.getElementById("contactMessage").value.trim();
    const output = document.getElementById("formMessage");
    
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    
    output.style.color = "red";
    output.innerText = "";

    if (name === "") {
        output.innerText = "Full Name is required.";
        return false;
    }
    
    if (email === "") {
        output.innerText = "Email Address is required.";
        return false;
    } else if (!emailRegex.test(email)) {
        output.innerText = "Please enter a valid email address.";
        return false;
    }

    if (message === "") {
        output.innerText = "Message is required.";
        return false;
    }

    output.style.color = "lightgreen";
    output.innerText = "Message Sent Successfully! We will respond shortly.";
    
    document.getElementById("contactForm").reset();
    return true;
}